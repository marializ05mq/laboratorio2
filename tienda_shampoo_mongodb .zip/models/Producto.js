
const mongoose = require('mongoose');

const productoSchema = new mongoose.Schema({
  nombre: String,
  marca: String,
  descripcion: String,
  precio: Number,
  stock: Number,
  categoria: String,
  imagen: String,
  activo: { type: Boolean, default: true }
});

module.exports = mongoose.model('Producto', productoSchema);
