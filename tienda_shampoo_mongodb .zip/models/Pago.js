
const mongoose = require('mongoose');

const pagoSchema = new mongoose.Schema({
  pedidoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Pedido' },
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' },
  monto: Number,
  metodo: { type: String, enum: ['tarjeta', 'efectivo', 'qr'] },
  estado: { type: String, enum: ['pagado', 'pendiente'], default: 'pendiente' },
  fechaPago: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Pago', pagoSchema);
